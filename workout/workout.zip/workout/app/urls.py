from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('add',views.addWorkout,name='add_workout'),
    path('addexercise/<int:id>',views.addExersice,name='add_exercise'),
    path('disp',views.dispData,name="disp")
]