from django.shortcuts import render,redirect
from .models import Workout,Exercise
from django import template

register = template.Library()
@register.filter
def index(list, index):
    return list[index]

# Create your views here.
def index(request):
  return render(request,'app/index.html')
  
def addWorkout(request):
  if request.method == "POST":
    dt = request.POST.get('date')
    print('date=',dt)
    wf = request.POST.get('workout')
    ne = request.POST.get('no_of_exercise')
    ns = request.POST.get('no_of_set')
    workout = Workout.objects.create(date=dt,Workout_for=wf,no_of_workout=ne,no_of_set=ns)
  return redirect('addexercise/'+str(workout.pk))
  
def addExersice(request,id):
  workout = Workout.objects.get(pk=id)
  ex =[]
  rep = []
  params = {
    'workouts':workout,
    'range' : range(1,int(workout.no_of_workout)+1)
  }
  if request.method == "POST":
    for i in range(1,int(workout.no_of_workout)+1):
      ex.append(request.POST['exersice'+str(i)])
      rep.append(request.POST['repeatation'+str(i)])
    for i in range(len(ex)):
      exersice = Exercise.objects.create(exercise = ex[i],repeatation = rep[i],workout = workout)
    return redirect('index')
  return render(request,'app/add_exersice.html',params)
  
def dispData(request):
  workout = Workout.objects.all().order_by("-date")
  ex = []
  for i in workout:
    ex.append( Exercise.objects.filter(workout=i))
  print(type(ex))
  params = {
    'workouts':workout,
    'exersices':ex,
    'range': range(1,len(ex)+1)
  }
  return render(request,'app/disp.html',params)
  
